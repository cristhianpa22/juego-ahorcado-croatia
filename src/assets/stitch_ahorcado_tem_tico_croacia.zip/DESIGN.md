---
name: Adriatic Pulse
colors:
  surface: '#f9f9ff'
  surface-dim: '#cfdaf2'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#dee8ff'
  surface-container-highest: '#d8e3fb'
  on-surface: '#111c2d'
  on-surface-variant: '#603e39'
  inverse-surface: '#263143'
  inverse-on-surface: '#ecf1ff'
  outline: '#956d67'
  outline-variant: '#ebbbb4'
  surface-tint: '#c00100'
  primary: '#bc0100'
  on-primary: '#ffffff'
  primary-container: '#eb0000'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb4a8'
  secondary: '#0001c0'
  on-secondary: '#ffffff'
  secondary-container: '#080cff'
  on-secondary-container: '#b6baff'
  tertiary: '#4e5e68'
  on-tertiary: '#ffffff'
  tertiary-container: '#667781'
  on-tertiary-container: '#fbfcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad4'
  primary-fixed-dim: '#ffb4a8'
  on-primary-fixed: '#410000'
  on-primary-fixed-variant: '#930100'
  secondary-fixed: '#e0e0ff'
  secondary-fixed-dim: '#bec2ff'
  on-secondary-fixed: '#00006e'
  on-secondary-fixed-variant: '#0000ef'
  tertiary-fixed: '#d3e5f1'
  tertiary-fixed-dim: '#b7c9d5'
  on-tertiary-fixed: '#0c1e26'
  on-tertiary-fixed-variant: '#384953'
  background: '#f9f9ff'
  on-background: '#111c2d'
  surface-variant: '#d8e3fb'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 42px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 28px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1200px
  gutter: 24px
  margin-mobile: 16px
  stack-sm: 4px
  stack-md: 16px
  stack-lg: 32px
---

## Brand & Style
The design system celebrates the vibrant spirit of Croatia through a playful yet professional interface. It balances the energetic national identity—represented by the iconic red and white *šahovnica*—with the serene, sun-soaked atmosphere of the Adriatic coast. 

The aesthetic is **Corporate Modern** with a **Tactile** twist. It avoids the heaviness of traditional sports branding, opting instead for a "Mediterranean Tech" feel: airy, high-contrast, and deeply organized. The goal is to evoke a sense of a premium summer getaway—bright, clean, and refreshing—while maintaining the mechanical precision required for a high-stakes word game.

## Colors
The palette is rooted in the Croatian tricolor but softened by coastal influences.

- **Primary (Vibrant Red):** Used for critical actions, the "Hangman" progress state, and key brand accents. It is the color of the *šahovnica* tiles.
- **Secondary (Deep Blue):** Represents the deep Adriatic. Used for primary navigation, success states, and stable structural elements.
- **Tertiary (Azure Mist):** A light, sun-washed blue used for large background surfaces and "water" metaphors.
- **Neutral (Slate):** A deep, professional grey for high-readability typography and borders.

**The Checkerboard Pattern:** The red and white pattern should be used sparingly as a decorative trim or a subtle background texture (at 5-10% opacity) to prevent visual fatigue.

## Typography
The design system utilizes **Plus Jakarta Sans** for its friendly, open counters and modern geometric structure. 

- **Display Styles:** Use the Bold or ExtraBold weights for the "hidden word" blanks to ensure maximum legibility during gameplay.
- **Rhythm:** Generous line heights are maintained to reflect the breezy, coastal personality of the brand.
- **Accessibility:** Ensure the red primary color is only used for headlines or large labels to maintain sufficient contrast against white backgrounds.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy on desktop to create a focused, "game board" feel, while transitioning to a fluid model on mobile.

- **Desktop:** 12-column grid centered in a 1200px container. The Hangman illustration occupies the left 5 columns, while the game interaction (word blanks and keyboard) occupies the right 7.
- **Mobile:** A single-column vertical stack. The Hangman illustration is scaled down at the top, followed by the word display, then the letter grid at the bottom for easy thumb reach.
- **Spacing:** Use an 8px base unit. Component padding should be generous (16px/24px) to emphasize the airy, Mediterranean vibe.

## Elevation & Depth
Depth is created through **Ambient Shadows** and **Tonal Layering**. 

- **Surfaces:** Use white containers against the Azure Mist (#E0F2FE) background to create a "floating" effect.
- **Shadows:** Shadows are highly diffused with a slight blue tint (`rgba(0, 0, 255, 0.08)`) rather than pure black. This mimics the soft, bright light of a coastal noon.
- **Depth Levels:** 
  - *Level 0 (Background):* Azure Mist.
  - *Level 1 (Cards):* White with soft shadow.
  - *Level 2 (Interactive Elements):* Buttons and keys with a slightly more pronounced shadow that disappears on click (simulating a physical press).

## Shapes
The shape language is consistently **Rounded**, avoiding sharp corners to maintain a friendly and approachable game environment.

- **Interactive Elements:** Buttons and letter keys use a 0.5rem (8px) radius. 
- **Containers:** Large game boards and modals use a 1rem (16px) or 1.5rem (24px) radius.
- **Icons:** Use thick-stroke (2pt) icons with rounded caps to match the typography's weight.

## Components
- **Letter Keys:** These should look tactile. Default state is white with a Deep Blue border. "Found" letters turn Deep Blue with white text. "Incorrect" letters turn Vibrant Red with white text.
- **Word Blanks:** Heavy horizontal bars (4px thick) using the Deep Blue color. When a letter is revealed, it sits 8px above the bar.
- **Primary Button:** Solid Vibrant Red with white text. Use a subtle "bounce" animation on hover.
- **Hangman Gallows:** Stylized with a smooth, dark wood texture or a minimalist Deep Blue vector line.
- **Game Progress Chips:** Small rounded pills indicating difficulty (e.g., "Lako," "Srednje," "Teško") using the Tertiary blue background.
- **Success Modal:** Features a celebratory *šahovnica* pattern border and a large "Pobjeda!" (Victory) headline.